import { Controller, Get, Query, HttpStatus, HttpCode } from '@nestjs/common';
import { AggregationService } from './aggregation.service';
import { IResponse } from '../common/interfaces';

@Controller('analytics')
export class AnalyticsController {
  constructor(private readonly aggregationService: AggregationService) {}

  @Get('category-subcategory-count')
  @HttpCode(HttpStatus.OK)
  async getCategoryWithSubCategoryCounts(): Promise<IResponse<any[]>> {
    const data = await this.aggregationService.getCategoryWithSubCategoryCounts();
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Category subcategory counts retrieved successfully',
      data,
    };
  }

  @Get('category-subcategory-count-paginated')
  @HttpCode(HttpStatus.OK)
  async getCategoryWithSubCategoryCountsPaginated(
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ): Promise<IResponse<any>> {
    const pageNum = parseInt(page || '1') || 1;
    const limitNum = parseInt(limit || '10') || 10;
    const data = await this.aggregationService.getCategoryWithSubCategoryCountsPaginated(pageNum, limitNum);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Paginated category subcategory counts retrieved successfully',
      data,
    };
  }

  @Get('category-subcategory-course-stats')
  @HttpCode(HttpStatus.OK)
  async getCategoryWithSubCategoryAndCourseStats(): Promise<IResponse<any[]>> {
    const data = await this.aggregationService.getCategoryWithSubCategoryAndCourseStats();
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Category subcategory course stats retrieved successfully',
      data,
    };
  }
}
