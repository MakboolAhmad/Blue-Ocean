import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AggregationService } from './aggregation.service';
import { AnalyticsController } from './analytics.controller';
import { Category, CategorySchema } from '../modules/category/schemas/category.schema';
import { SubCategory, SubCategorySchema } from '../modules/subcategory/schemas/subcategory.schema';
import { Course, CourseSchema } from '../modules/course/schemas/course.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Category.name, schema: CategorySchema },
      { name: SubCategory.name, schema: SubCategorySchema },
      { name: Course.name, schema: CourseSchema },
    ]),
  ],
  controllers: [AnalyticsController],
  providers: [AggregationService],
  exports: [AggregationService],
})
export class DatabaseModule {}
