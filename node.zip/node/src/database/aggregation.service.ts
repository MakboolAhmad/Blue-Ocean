import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Category } from '../modules/category/schemas/category.schema';

export interface CategoryWithSubCategoryCount {
  _id: string;
  name: string;
  description: string;
  subCategoryCount: number;
  createdAt: Date;
  updatedAt: Date;
}

@Injectable()
export class AggregationService {
  constructor(
    @InjectModel(Category.name) private categoryModel: Model<Category>,
  ) {}

  /**
   * MongoDB Aggregation Pipeline to get each Category with the count of SubCategories
   * This demonstrates:
   * - $lookup: Joins with SubCategory collection
   * - $match: Filters out deleted records
   * - $group: Groups and counts
   * - $project: Shapes the output
   * - $sort: Sorts by count descending
   */
  async getCategoryWithSubCategoryCounts(): Promise<CategoryWithSubCategoryCount[]> {
    const result = await this.categoryModel.aggregate([
      // First, filter out deleted categories
      {
        $match: {
          isDeleted: false,
        },
      },
      // Lookup subcategories from SubCategory collection
      {
        $lookup: {
          from: 'subcategories',
          localField: '_id',
          foreignField: 'categoryId',
          as: 'subCategories',
        },
      },
      // Add a field with the count of subcategories
      {
        $addFields: {
          subCategoryCount: {
            $size: {
              $filter: {
                input: '$subCategories',
                as: 'sub',
                cond: { $eq: ['$$sub.isDeleted', false] },
              },
            },
          },
        },
      },
      // Project the desired fields
      {
        $project: {
          _id: 1,
          name: 1,
          description: 1,
          subCategoryCount: 1,
          createdAt: 1,
          updatedAt: 1,
          subCategories: 0, // Exclude the full subcategories array
        },
      },
      // Sort by count in descending order
      {
        $sort: {
          subCategoryCount: -1,
          name: 1,
        },
      },
    ]);

    return result;
  }

  /**
   * Alternative aggregation with pagination
   */
  async getCategoryWithSubCategoryCountsPaginated(
    page: number = 1,
    limit: number = 10,
  ): Promise<{ data: CategoryWithSubCategoryCount[]; total: number; pages: number }> {
    const skip = (page - 1) * limit;

    const result = await this.categoryModel.aggregate([
      {
        $match: {
          isDeleted: false,
        },
      },
      {
        $lookup: {
          from: 'subcategories',
          localField: '_id',
          foreignField: 'categoryId',
          as: 'subCategories',
        },
      },
      {
        $addFields: {
          subCategoryCount: {
            $size: {
              $filter: {
                input: '$subCategories',
                as: 'sub',
                cond: { $eq: ['$$sub.isDeleted', false] },
              },
            },
          },
        },
      },
      {
        $facet: {
          metadata: [{ $count: 'total' }],
          data: [
            {
              $project: {
                _id: 1,
                name: 1,
                description: 1,
                subCategoryCount: 1,
                createdAt: 1,
                updatedAt: 1,
              },
            },
            { $sort: { subCategoryCount: -1, name: 1 } },
            { $skip: skip },
            { $limit: limit },
          ],
        },
      },
      // Unwind the results
      {
        $project: {
          data: 1,
          total: { $arrayElemAt: ['$metadata.total', 0] },
        },
      },
    ]);

    const { data, total } = result[0] || { data: [], total: 0 };
    const pages = Math.ceil((total || 0) / limit);

    return { data, total: total || 0, pages };
  }

  /**
   * Advanced aggregation: Category with SubCategories and their Course counts
   */
  async getCategoryWithSubCategoryAndCourseStats(): Promise<any[]> {
    return this.categoryModel.aggregate([
      {
        $match: {
          isDeleted: false,
        },
      },
      {
        $lookup: {
          from: 'subcategories',
          localField: '_id',
          foreignField: 'categoryId',
          as: 'subCategories',
        },
      },
      {
        $unwind: {
          path: '$subCategories',
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $lookup: {
          from: 'courses',
          let: { subCategoryId: '$subCategories._id' },
          pipeline: [
            {
              $match: {
                $expr: { $in: ['$$subCategoryId', '$subCategoryIds'] },
                isDeleted: false,
              },
            },
          ],
          as: 'courses',
        },
      },
      {
        $group: {
          _id: '$_id',
          categoryName: { $first: '$name' },
          categoryDescription: { $first: '$description' },
          subCategories: {
            $push: {
              _id: '$subCategories._id',
              name: '$subCategories.name',
              courseCount: { $size: '$courses' },
            },
          },
        },
      },
      {
        $addFields: {
          totalSubCategories: { $size: '$subCategories' },
          totalCourses: {
            $sum: '$subCategories.courseCount',
          },
        },
      },
      {
        $sort: {
          totalSubCategories: -1,
          categoryName: 1,
        },
      },
    ]);
  }
}
