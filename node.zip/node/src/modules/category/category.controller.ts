import { Controller, Get, Post, Put, Delete, Body, Param, Query, HttpStatus, HttpCode } from '@nestjs/common';
import { CategoryService } from './category.service';
import { CreateCategoryDto, UpdateCategoryDto } from './dto/category.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { IResponse, IPaginationResult } from '../../common/interfaces';
import { Category } from './schemas/category.schema';

@Controller('categories')
export class CategoryController {
  constructor(private readonly categoryService: CategoryService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createCategoryDto: CreateCategoryDto): Promise<IResponse<Category>> {
    const data = await this.categoryService.create(createCategoryDto);
    return {
      success: true,
      statusCode: HttpStatus.CREATED,
      message: 'Category created successfully',
      data,
    };
  }

  @Get()
  @HttpCode(HttpStatus.OK)
  async findAll(@Query() paginationDto: PaginationDto): Promise<IResponse<IPaginationResult<Category>>> {
    const data = await this.categoryService.findAll(paginationDto);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Categories retrieved successfully',
      data,
    };
  }

  @Get(':id')
  @HttpCode(HttpStatus.OK)
  async findById(@Param('id') id: string): Promise<IResponse<Category>> {
    const data = await this.categoryService.findById(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Category retrieved successfully',
      data,
    };
  }

  @Put(':id')
  @HttpCode(HttpStatus.OK)
  async update(
    @Param('id') id: string,
    @Body() updateCategoryDto: UpdateCategoryDto,
  ): Promise<IResponse<Category>> {
    const data = await this.categoryService.update(id, updateCategoryDto);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Category updated successfully',
      data,
    };
  }

  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  async delete(@Param('id') id: string): Promise<IResponse<{ message: string }>> {
    const data = await this.categoryService.delete(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Category soft deleted successfully',
      data,
    };
  }

  @Delete(':id/permanent')
  @HttpCode(HttpStatus.OK)
  async permanentDelete(@Param('id') id: string): Promise<IResponse<{ message: string }>> {
    const data = await this.categoryService.permanentDelete(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Category permanently deleted',
      data,
    };
  }

  @Put(':id/restore')
  @HttpCode(HttpStatus.OK)
  async restore(@Param('id') id: string): Promise<IResponse<Category>> {
    const data = await this.categoryService.restore(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Category restored successfully',
      data,
    };
  }
}
