import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Category, CategoryDocument } from './schemas/category.schema';
import { CreateCategoryDto, UpdateCategoryDto } from './dto/category.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { IPaginationResult } from '../../common/interfaces';

@Injectable()
export class CategoryService {
  constructor(
    @InjectModel(Category.name) private categoryModel: Model<CategoryDocument>,
  ) {}

  async create(createCategoryDto: CreateCategoryDto): Promise<Category> {
    const existingCategory = await this.categoryModel.findOne({
      name: createCategoryDto.name,
      isDeleted: false,
    });

    if (existingCategory) {
      throw new BadRequestException('Category with this name already exists');
    }

    const newCategory = new this.categoryModel(createCategoryDto);
    return await newCategory.save();
  }

  async findAll(paginationDto: PaginationDto): Promise<IPaginationResult<Category>> {
    const page = paginationDto.page || 1;
    const limit = paginationDto.limit || 10;
    const skip = (page - 1) * limit;

    const query: any = { isDeleted: false };

    if (paginationDto.search) {
      query.name = { $regex: paginationDto.search, $options: 'i' };
    }

    const [data, total] = await Promise.all([
      this.categoryModel.find(query).sort(this.parseSortString(paginationDto.sort)).skip(skip).limit(limit),
      this.categoryModel.countDocuments(query),
    ]);

    return {
      data,
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    };
  }

  async findById(id: string): Promise<Category> {
    const category = await this.categoryModel.findOne({
      _id: id,
      isDeleted: false,
    });

    if (!category) {
      throw new NotFoundException(`Category with ID ${id} not found`);
    }

    return category;
  }

  async update(id: string, updateCategoryDto: UpdateCategoryDto): Promise<Category> {
    if (updateCategoryDto.name) {
      const existingCategory = await this.categoryModel.findOne({
        name: updateCategoryDto.name,
        _id: { $ne: id },
        isDeleted: false,
      });

      if (existingCategory) {
        throw new BadRequestException('Category with this name already exists');
      }
    }

    const updatedCategory = await this.categoryModel.findByIdAndUpdate(
      id,
      updateCategoryDto,
      { new: true, runValidators: true },
    );

    if (!updatedCategory) {
      throw new NotFoundException(`Category with ID ${id} not found`);
    }

    return updatedCategory;
  }

  async delete(id: string): Promise<{ message: string }> {
    const result = await this.categoryModel.findByIdAndUpdate(
      id,
      { isDeleted: true },
      { new: true },
    );

    if (!result) {
      throw new NotFoundException(`Category with ID ${id} not found`);
    }

    return { message: 'Category soft deleted successfully' };
  }

  async permanentDelete(id: string): Promise<{ message: string }> {
    const result = await this.categoryModel.findByIdAndDelete(id);

    if (!result) {
      throw new NotFoundException(`Category with ID ${id} not found`);
    }

    return { message: 'Category permanently deleted' };
  }

  async restore(id: string): Promise<Category> {
    const category = await this.categoryModel.findByIdAndUpdate(
      id,
      { isDeleted: false },
      { new: true },
    );

    if (!category) {
      throw new NotFoundException(`Category with ID ${id} not found`);
    }

    return category;
  }

  private parseSortString(sortStr?: string): any {
    if (!sortStr) return { createdAt: -1 };

    const sortObject: any = {};
    const fields = sortStr.split(',');

    fields.forEach((field) => {
      if (field.startsWith('-')) {
        sortObject[field.substring(1)] = -1;
      } else {
        sortObject[field] = 1;
      }
    });

    return sortObject;
  }
}
