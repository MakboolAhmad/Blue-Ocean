import { IsString, IsOptional, IsNotEmpty, MaxLength, IsMongoId } from 'class-validator';
import { Types } from 'mongoose';

export class CreateSubCategoryDto {
  @IsNotEmpty()
  @IsString()
  @MaxLength(100)
  name!: string;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;

  @IsNotEmpty()
  @IsMongoId()
  categoryId!: Types.ObjectId | string;
}

export class UpdateSubCategoryDto {
  @IsOptional()
  @IsString()
  @MaxLength(100)
  name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  description?: string;

  @IsOptional()
  @IsMongoId()
  categoryId?: Types.ObjectId | string;
}
