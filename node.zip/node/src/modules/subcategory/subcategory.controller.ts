import { Controller, Get, Post, Put, Delete, Body, Param, Query, HttpStatus, HttpCode } from '@nestjs/common';
import { SubCategoryService } from './subcategory.service';
import { CreateSubCategoryDto, UpdateSubCategoryDto } from './dto/subcategory.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { IResponse, IPaginationResult } from '../../common/interfaces';
import { SubCategory } from './schemas/subcategory.schema';

@Controller('subcategories')
export class SubCategoryController {
  constructor(private readonly subCategoryService: SubCategoryService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createSubCategoryDto: CreateSubCategoryDto): Promise<IResponse<SubCategory>> {
    const data = await this.subCategoryService.create(createSubCategoryDto);
    return {
      success: true,
      statusCode: HttpStatus.CREATED,
      message: 'SubCategory created successfully',
      data,
    };
  }

  @Get()
  @HttpCode(HttpStatus.OK)
  async findAll(@Query() paginationDto: PaginationDto): Promise<IResponse<IPaginationResult<SubCategory>>> {
    const data = await this.subCategoryService.findAll(paginationDto);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'SubCategories retrieved successfully',
      data,
    };
  }

  @Get('category/:categoryId')
  @HttpCode(HttpStatus.OK)
  async findByCategoryId(@Param('categoryId') categoryId: string): Promise<IResponse<SubCategory[]>> {
    const data = await this.subCategoryService.findByCategoryId(categoryId);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'SubCategories for category retrieved successfully',
      data,
    };
  }

  @Get(':id')
  @HttpCode(HttpStatus.OK)
  async findById(@Param('id') id: string): Promise<IResponse<SubCategory>> {
    const data = await this.subCategoryService.findById(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'SubCategory retrieved successfully',
      data,
    };
  }

  @Put(':id')
  @HttpCode(HttpStatus.OK)
  async update(
    @Param('id') id: string,
    @Body() updateSubCategoryDto: UpdateSubCategoryDto,
  ): Promise<IResponse<SubCategory>> {
    const data = await this.subCategoryService.update(id, updateSubCategoryDto);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'SubCategory updated successfully',
      data,
    };
  }

  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  async delete(@Param('id') id: string): Promise<IResponse<{ message: string }>> {
    const data = await this.subCategoryService.delete(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'SubCategory soft deleted successfully',
      data,
    };
  }

  @Delete(':id/permanent')
  @HttpCode(HttpStatus.OK)
  async permanentDelete(@Param('id') id: string): Promise<IResponse<{ message: string }>> {
    const data = await this.subCategoryService.permanentDelete(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'SubCategory permanently deleted',
      data,
    };
  }

  @Put(':id/restore')
  @HttpCode(HttpStatus.OK)
  async restore(@Param('id') id: string): Promise<IResponse<SubCategory>> {
    const data = await this.subCategoryService.restore(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'SubCategory restored successfully',
      data,
    };
  }
}
