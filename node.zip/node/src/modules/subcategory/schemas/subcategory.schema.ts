import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, HydratedDocument, Types } from 'mongoose';
import { Category } from '../../category/schemas/category.schema';

export type SubCategoryDocument = HydratedDocument<SubCategory>;

@Schema({ timestamps: true })
export class SubCategory extends Document {
  @Prop({ required: true, unique: true })
  name!: string;

  @Prop({ required: false })
  description?: string;

  @Prop({ type: Types.ObjectId, ref: 'Category', required: true })
  categoryId!: Types.ObjectId;

  @Prop({ default: false })
  isDeleted!: boolean;

  @Prop()
  createdAt?: Date;

  @Prop()
  updatedAt?: Date;
}

export const SubCategorySchema = SchemaFactory.createForClass(SubCategory);

// Index for better query performance
SubCategorySchema.index({ name: 1, isDeleted: 1 });
SubCategorySchema.index({ categoryId: 1, isDeleted: 1 });
SubCategorySchema.index({ createdAt: -1 });
