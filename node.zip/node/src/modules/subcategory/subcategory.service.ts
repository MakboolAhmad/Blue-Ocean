import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { SubCategory, SubCategoryDocument } from './schemas/subcategory.schema';
import { CreateSubCategoryDto, UpdateSubCategoryDto } from './dto/subcategory.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { IPaginationResult } from '../../common/interfaces';
import { CategoryService } from '../category/category.service';

@Injectable()
export class SubCategoryService {
  constructor(
    @InjectModel(SubCategory.name) private subCategoryModel: Model<SubCategoryDocument>,
    private categoryService: CategoryService,
  ) {}

  async create(createSubCategoryDto: CreateSubCategoryDto): Promise<SubCategory> {
    // Validate that category exists
    await this.categoryService.findById(createSubCategoryDto.categoryId.toString());

    const existingSubCategory = await this.subCategoryModel.findOne({
      name: createSubCategoryDto.name,
      isDeleted: false,
    });

    if (existingSubCategory) {
      throw new BadRequestException('SubCategory with this name already exists');
    }

    const newSubCategory = new this.subCategoryModel({
      ...createSubCategoryDto,
      categoryId: new Types.ObjectId(createSubCategoryDto.categoryId),
    });

    return await newSubCategory.save();
  }

  async findAll(paginationDto: PaginationDto): Promise<IPaginationResult<SubCategory>> {
    const page = paginationDto.page || 1;
    const limit = paginationDto.limit || 10;
    const skip = (page - 1) * limit;

    const query: any = { isDeleted: false };

    if (paginationDto.search) {
      query.name = { $regex: paginationDto.search, $options: 'i' };
    }

    const [data, total] = await Promise.all([
      this.subCategoryModel
        .find(query)
        .sort(this.parseSortString(paginationDto.sort))
        .skip(skip)
        .limit(limit)
        .populate('categoryId'),
      this.subCategoryModel.countDocuments(query),
    ]);

    return {
      data,
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    };
  }

  async findById(id: string): Promise<SubCategory> {
    const subCategory = await this.subCategoryModel.findOne({
      _id: id,
      isDeleted: false,
    }).populate('categoryId');

    if (!subCategory) {
      throw new NotFoundException(`SubCategory with ID ${id} not found`);
    }

    return subCategory;
  }

  async findByCategoryId(categoryId: string): Promise<SubCategory[]> {
    return this.subCategoryModel.find({
      categoryId: new Types.ObjectId(categoryId),
      isDeleted: false,
    });
  }

  async update(id: string, updateSubCategoryDto: UpdateSubCategoryDto): Promise<SubCategory> {
    if (updateSubCategoryDto.categoryId) {
      // Validate that new category exists
      await this.categoryService.findById(updateSubCategoryDto.categoryId.toString());
    }

    if (updateSubCategoryDto.name) {
      const existingSubCategory = await this.subCategoryModel.findOne({
        name: updateSubCategoryDto.name,
        _id: { $ne: id },
        isDeleted: false,
      });

      if (existingSubCategory) {
        throw new BadRequestException('SubCategory with this name already exists');
      }
    }

    const updateData = {
      ...updateSubCategoryDto,
      ...(updateSubCategoryDto.categoryId && {
        categoryId: new Types.ObjectId(updateSubCategoryDto.categoryId),
      }),
    };

    const updatedSubCategory = await this.subCategoryModel.findByIdAndUpdate(
      id,
      updateData,
      { new: true, runValidators: true },
    ).populate('categoryId');

    if (!updatedSubCategory) {
      throw new NotFoundException(`SubCategory with ID ${id} not found`);
    }

    return updatedSubCategory;
  }

  async delete(id: string): Promise<{ message: string }> {
    const result = await this.subCategoryModel.findByIdAndUpdate(
      id,
      { isDeleted: true },
      { new: true },
    );

    if (!result) {
      throw new NotFoundException(`SubCategory with ID ${id} not found`);
    }

    return { message: 'SubCategory soft deleted successfully' };
  }

  async permanentDelete(id: string): Promise<{ message: string }> {
    const result = await this.subCategoryModel.findByIdAndDelete(id);

    if (!result) {
      throw new NotFoundException(`SubCategory with ID ${id} not found`);
    }

    return { message: 'SubCategory permanently deleted' };
  }

  async restore(id: string): Promise<SubCategory> {
    const subCategory = await this.subCategoryModel.findByIdAndUpdate(
      id,
      { isDeleted: false },
      { new: true },
    ).populate('categoryId');

    if (!subCategory) {
      throw new NotFoundException(`SubCategory with ID ${id} not found`);
    }

    return subCategory;
  }

  private parseSortString(sortStr?: string): any {
    if (!sortStr) return { createdAt: -1 };

    const sortObject: any = {};
    const fields = sortStr.split(',');

    fields.forEach((field) => {
      if (field.startsWith('-')) {
        sortObject[field.substring(1)] = -1;
      } else {
        sortObject[field] = 1;
      }
    });

    return sortObject;
  }
}
