import { Controller, Get, Post, Put, Delete, Body, Param, Query, HttpStatus, HttpCode } from '@nestjs/common';
import { CourseService } from './course.service';
import { CreateCourseDto, UpdateCourseDto } from './dto/course.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { IResponse, IPaginationResult } from '../../common/interfaces';
import { Course } from './schemas/course.schema';

@Controller('courses')
export class CourseController {
  constructor(private readonly courseService: CourseService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createCourseDto: CreateCourseDto): Promise<IResponse<Course>> {
    const data = await this.courseService.create(createCourseDto);
    return {
      success: true,
      statusCode: HttpStatus.CREATED,
      message: 'Course created successfully',
      data,
    };
  }

  @Get()
  @HttpCode(HttpStatus.OK)
  async findAll(@Query() paginationDto: PaginationDto): Promise<IResponse<IPaginationResult<Course>>> {
    const data = await this.courseService.findAll(paginationDto);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Courses retrieved successfully',
      data,
    };
  }

  @Get('category/:categoryId')
  @HttpCode(HttpStatus.OK)
  async findByCategory(@Param('categoryId') categoryId: string): Promise<IResponse<Course[]>> {
    const data = await this.courseService.findByCategory(categoryId);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Courses for category retrieved successfully',
      data,
    };
  }

  @Get('subcategory/:subCategoryId')
  @HttpCode(HttpStatus.OK)
  async findBySubCategory(@Param('subCategoryId') subCategoryId: string): Promise<IResponse<Course[]>> {
    const data = await this.courseService.findBySubCategory(subCategoryId);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Courses for subcategory retrieved successfully',
      data,
    };
  }

  @Get(':id')
  @HttpCode(HttpStatus.OK)
  async findById(@Param('id') id: string): Promise<IResponse<Course>> {
    const data = await this.courseService.findById(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Course retrieved successfully',
      data,
    };
  }

  @Put(':id')
  @HttpCode(HttpStatus.OK)
  async update(
    @Param('id') id: string,
    @Body() updateCourseDto: UpdateCourseDto,
  ): Promise<IResponse<Course>> {
    const data = await this.courseService.update(id, updateCourseDto);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Course updated successfully',
      data,
    };
  }

  @Delete(':id')
  @HttpCode(HttpStatus.OK)
  async delete(@Param('id') id: string): Promise<IResponse<{ message: string }>> {
    const data = await this.courseService.delete(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Course soft deleted successfully',
      data,
    };
  }

  @Delete(':id/permanent')
  @HttpCode(HttpStatus.OK)
  async permanentDelete(@Param('id') id: string): Promise<IResponse<{ message: string }>> {
    const data = await this.courseService.permanentDelete(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Course permanently deleted',
      data,
    };
  }

  @Put(':id/restore')
  @HttpCode(HttpStatus.OK)
  async restore(@Param('id') id: string): Promise<IResponse<Course>> {
    const data = await this.courseService.restore(id);
    return {
      success: true,
      statusCode: HttpStatus.OK,
      message: 'Course restored successfully',
      data,
    };
  }
}
