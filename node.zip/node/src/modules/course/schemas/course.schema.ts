import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, HydratedDocument, Types } from 'mongoose';
import { Category } from '../../category/schemas/category.schema';
import { SubCategory } from '../../subcategory/schemas/subcategory.schema';

export type CourseDocument = HydratedDocument<Course>;

@Schema({ timestamps: true })
export class Course extends Document {
  @Prop({ required: true, unique: true })
  name!: string;

  @Prop({ required: false })
  description?: string;

  @Prop({ required: false })
  instructor?: string;

  @Prop({ type: [Types.ObjectId], ref: 'Category', required: true })
  categoryIds!: Types.ObjectId[];

  @Prop({ type: [Types.ObjectId], ref: 'SubCategory', required: true })
  subCategoryIds!: Types.ObjectId[];

  @Prop({ required: false, default: 0 })
  duration?: number; // in hours

  @Prop({ required: false, default: 0 })
  price?: number;

  @Prop({ default: false })
  isDeleted!: boolean;

  @Prop()
  createdAt?: Date;

  @Prop()
  updatedAt?: Date;
}

export const CourseSchema = SchemaFactory.createForClass(Course);

// Index for better query performance
CourseSchema.index({ name: 1, isDeleted: 1 });
CourseSchema.index({ categoryIds: 1, isDeleted: 1 });
CourseSchema.index({ subCategoryIds: 1, isDeleted: 1 });
CourseSchema.index({ createdAt: -1 });
