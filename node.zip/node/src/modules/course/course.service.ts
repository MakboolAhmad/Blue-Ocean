import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types, ClientSession } from 'mongoose';
import { Course, CourseDocument } from './schemas/course.schema';
import { CreateCourseDto, UpdateCourseDto } from './dto/course.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { IPaginationResult } from '../../common/interfaces';
import { CategoryService } from '../category/category.service';
import { SubCategoryService } from '../subcategory/subcategory.service';

@Injectable()
export class CourseService {
  constructor(
    @InjectModel(Course.name) private courseModel: Model<CourseDocument>,
    private categoryService: CategoryService,
    private subCategoryService: SubCategoryService,
  ) {}

  async create(createCourseDto: CreateCourseDto): Promise<Course> {
    // Get a session for transaction support
    const session = await this.courseModel.startSession();
    session.startTransaction();

    try {
      // Validate course name is unique
      const existingCourse = await this.courseModel.findOne({
        name: createCourseDto.name,
        isDeleted: false,
      });

      if (existingCourse) {
        throw new BadRequestException('Course with this name already exists');
      }

      // Convert to ObjectIds
      const categoryIds = createCourseDto.categoryIds.map((id) => new Types.ObjectId(id as string));
      const subCategoryIds = createCourseDto.subCategoryIds.map((id) => new Types.ObjectId(id as string));

      // Validate all categories exist
      for (const categoryId of categoryIds) {
        await this.categoryService.findById(categoryId.toString());
      }

      // Validate all subcategories exist and belong to the provided categories
      for (const subCategoryId of subCategoryIds) {
        const subCategory = await this.subCategoryService.findById(subCategoryId.toString());

        // Check if subcategory belongs to one of the selected categories
        const belongsToCategory = categoryIds.some((catId: Types.ObjectId) => catId.toString() === subCategory.categoryId.toString());

        if (!belongsToCategory) {
          throw new BadRequestException(
            `SubCategory ${subCategoryId} does not belong to any of the selected categories`,
          );
        }
      }

      // Create course
      const newCourse = new this.courseModel({
        ...createCourseDto,
        categoryIds,
        subCategoryIds,
      });

      const savedCourse = await newCourse.save({ session });

      await session.commitTransaction();
      return savedCourse;
    } catch (error) {
      await session.abortTransaction();
      throw error;
    } finally {
      await session.endSession();
    }
  }

  async findAll(paginationDto: PaginationDto): Promise<IPaginationResult<Course>> {
    const page = paginationDto.page || 1;
    const limit = paginationDto.limit || 10;
    const skip = (page - 1) * limit;

    const query: any = { isDeleted: false };

    if (paginationDto.search) {
      query.name = { $regex: paginationDto.search, $options: 'i' };
    }

    const [data, total] = await Promise.all([
      this.courseModel
        .find(query)
        .sort(this.parseSortString(paginationDto.sort))
        .skip(skip)
        .limit(limit)
        .populate('categoryIds')
        .populate('subCategoryIds'),
      this.courseModel.countDocuments(query),
    ]);

    return {
      data,
      total,
      page,
      limit,
      pages: Math.ceil(total / limit),
    };
  }

  async findById(id: string): Promise<Course> {
    const course = await this.courseModel
      .findOne({
        _id: id,
        isDeleted: false,
      })
      .populate('categoryIds')
      .populate('subCategoryIds');

    if (!course) {
      throw new NotFoundException(`Course with ID ${id} not found`);
    }

    return course;
  }

  async findByCategory(categoryId: string): Promise<Course[]> {
    return this.courseModel
      .find({
        categoryIds: new Types.ObjectId(categoryId),
        isDeleted: false,
      })
      .populate('categoryIds')
      .populate('subCategoryIds');
  }

  async findBySubCategory(subCategoryId: string): Promise<Course[]> {
    return this.courseModel
      .find({
        subCategoryIds: new Types.ObjectId(subCategoryId),
        isDeleted: false,
      })
      .populate('categoryIds')
      .populate('subCategoryIds');
  }

  async update(id: string, updateCourseDto: UpdateCourseDto): Promise<Course> {
    const session = await this.courseModel.startSession();
    session.startTransaction();

    try {
      // Validate course name is unique if being updated
      if (updateCourseDto.name) {
        const existingCourse = await this.courseModel.findOne({
          name: updateCourseDto.name,
          _id: { $ne: id },
          isDeleted: false,
        });

        if (existingCourse) {
          throw new BadRequestException('Course with this name already exists');
        }
      }

      // If categories or subcategories are being updated, validate
      let updateData: any = { ...updateCourseDto };

      if (updateCourseDto.categoryIds) {
        const categoryIds = updateCourseDto.categoryIds.map((id) => new Types.ObjectId(id as string));

        // Validate all categories exist
        for (const categoryId of categoryIds) {
          await this.categoryService.findById(categoryId.toString());
        }

        updateData.categoryIds = categoryIds;
      }

      if (updateCourseDto.subCategoryIds) {
        const subCategoryIds = updateCourseDto.subCategoryIds.map((id) => new Types.ObjectId(id as string));
        const categoryIds = updateData.categoryIds || (await this.getCourseCategories(id));

        // Validate all subcategories exist and belong to categories
        for (const subCategoryId of subCategoryIds) {
          const subCategory = await this.subCategoryService.findById(subCategoryId.toString());

          const belongsToCategory = categoryIds.some((catId: Types.ObjectId) => catId.toString() === subCategory.categoryId.toString());

          if (!belongsToCategory) {
            throw new BadRequestException(
              `SubCategory ${subCategoryId} does not belong to any of the selected categories`,
            );
          }
        }

        updateData.subCategoryIds = subCategoryIds;
      }

      const updatedCourse = await this.courseModel
        .findByIdAndUpdate(id, updateData, { new: true, runValidators: true, session })
        .populate('categoryIds')
        .populate('subCategoryIds');

      if (!updatedCourse) {
        throw new NotFoundException(`Course with ID ${id} not found`);
      }

      await session.commitTransaction();
      return updatedCourse;
    } catch (error) {
      await session.abortTransaction();
      throw error;
    } finally {
      await session.endSession();
    }
  }

  async delete(id: string): Promise<{ message: string }> {
    const result = await this.courseModel.findByIdAndUpdate(
      id,
      { isDeleted: true },
      { new: true },
    );

    if (!result) {
      throw new NotFoundException(`Course with ID ${id} not found`);
    }

    return { message: 'Course soft deleted successfully' };
  }

  async permanentDelete(id: string): Promise<{ message: string }> {
    const result = await this.courseModel.findByIdAndDelete(id);

    if (!result) {
      throw new NotFoundException(`Course with ID ${id} not found`);
    }

    return { message: 'Course permanently deleted' };
  }

  async restore(id: string): Promise<Course> {
    const course = await this.courseModel
      .findByIdAndUpdate(id, { isDeleted: false }, { new: true })
      .populate('categoryIds')
      .populate('subCategoryIds');

    if (!course) {
      throw new NotFoundException(`Course with ID ${id} not found`);
    }

    return course;
  }

  private async getCourseCategories(courseId: string): Promise<Types.ObjectId[]> {
    const course = await this.courseModel.findById(courseId);
    return course?.categoryIds || [];
  }

  private parseSortString(sortStr?: string): any {
    if (!sortStr) return { createdAt: -1 };

    const sortObject: any = {};
    const fields = sortStr.split(',');

    fields.forEach((field) => {
      if (field.startsWith('-')) {
        sortObject[field.substring(1)] = -1;
      } else {
        sortObject[field] = 1;
      }
    });

    return sortObject;
  }
}
