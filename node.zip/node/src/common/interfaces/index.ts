export interface IResponse<T> {
  success: boolean;
  message: string;
  data?: T;
  error?: any;
  statusCode: number;
}

export interface IPaginationQuery {
  page?: number;
  limit?: number;
  skip?: number;
  sort?: string;
  search?: string;
  [key: string]: any;
}

export interface IPaginationResult<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  pages: number;
}
