import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CategoryModule } from './modules/category/category.module';
import { SubCategoryModule } from './modules/subcategory/subcategory.module';
import { CourseModule } from './modules/course/course.module';
import { DatabaseModule } from './database/database.module';

@Module({
  imports: [
    MongooseModule.forRoot(process.env.MONGODB_URI || 'mongodb://localhost:27017/course-management'),
    CategoryModule,
    SubCategoryModule,
    CourseModule,
    DatabaseModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
